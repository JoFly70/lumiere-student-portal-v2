export default function App(){return React.createElement('div',null,'Lumiere Mock loads');}
const root=ReactDOM.createRoot(document.getElementById('root'));root.render(React.createElement(App));
